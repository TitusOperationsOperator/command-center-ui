import AppShell from '@/components/command-center/AppShell';

export default function Home() {
  return <AppShell />;
}
